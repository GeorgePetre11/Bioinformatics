import tkinter as tk
from tkinter import scrolledtext, messagebox
from itertools import product


class DNAAnalyzer:
    def __init__(self, root):
        self.root = root
        self.root.title("DNA Analyzer")
        self.root.geometry("1000x700")

        self.sequence = "TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA"

        self.setup_gui()
        self.analyze_sequence()

    def all_combinations(self, length):
        # generate nucleotide combos
        bases = ['A', 'C', 'G', 'T']
        combos = [''.join(p) for p in product(bases, repeat=length)]
        return combos

    def count_pattern(self, seq, pat):
        # simple counting
        count = 0
        for i in range(len(seq)-len(pat)+1):
            if seq[i:i+len(pat)] == pat:
                count += 1
        return count

    def analyze_sequence(self):
        # clear previous output
        self.output_text.delete(1.0, tk.END)

        self.output_text.insert(tk.END, f"Sequence: {self.sequence}\nLength: {len(self.sequence)}\n\n")

        # dinucleotides
        self.output_text.insert(tk.END, "Dinucleotide counts:\n")
        dinucs = self.all_combinations(2)
        total_di_pos = len(self.sequence)-1

        for d in dinucs:
            c = self.count_pattern(self.sequence, d)
            perc = (c/total_di_pos)*100 if total_di_pos else 0
            self.output_text.insert(tk.END, f"{d}: {c} ({perc:.2f}%)\n")

        self.output_text.insert(tk.END, "\nTrinucleotide counts:\n")
        trinucs = self.all_combinations(3)
        total_tri_pos = len(self.sequence)-2

        for t in trinucs:
            c = self.count_pattern(self.sequence, t)
            perc = (c/total_tri_pos)*100 if total_tri_pos else 0
            self.output_text.insert(tk.END, f"{t}: {c} ({perc:.2f}%)\n")

    def setup_gui(self):
        # sequence input display
        seq_frame = tk.Frame(self.root)
        seq_frame.pack(pady=10)
        tk.Label(seq_frame, text="DNA Sequence:").pack()
        seq_box = tk.Text(seq_frame, height=3, width=80)
        seq_box.insert(tk.END, self.sequence)
        seq_box.config(state=tk.DISABLED)
        seq_box.pack()

        # buttons
        btn_frame = tk.Frame(self.root)
        btn_frame.pack(pady=10)
        tk.Button(btn_frame, text="Analyze", command=self.analyze_sequence).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Save", command=self.save_results).pack(side=tk.LEFT, padx=5)

        # output
        self.output_text = scrolledtext.ScrolledText(self.root, width=100, height=30)
        self.output_text.pack(pady=10)

    def save_results(self):
        with open("results.txt", "w") as f:
            f.write(self.output_text.get(1.0, tk.END))
        messagebox.showinfo("Saved", "Results saved to results.txt")

def main():
    root = tk.Tk()
    app = DNAAnalyzer(root)
    root.mainloop()

if __name__ == "__main__":
    main()
