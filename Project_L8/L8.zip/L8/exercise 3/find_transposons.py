def reverse_complement(seq):
    complement = {'A': 'T', 'T': 'A', 'G': 'C', 'C': 'G'}
    return ''.join(complement.get(base, base) for base in reversed(seq))

def read_fasta(filename):
    with open(filename, 'r') as f:
        lines = f.readlines()
    sequence = ''.join([line.strip() for line in lines if not line.startswith('>')])
    header = [line.strip() for line in lines if line.startswith('>')][0]
    return header, sequence

def find_inverted_repeats(sequence, min_length=4, max_length=6, max_distance=1000):
    found_repeats = []
    seq_len = len(sequence)
    
    for length in range(min_length, max_length + 1):
        for i in range(0, seq_len - length, 100):
            left_seq = sequence[i:i + length]
            if 'N' in left_seq:
                continue
            
            right_seq_expected = reverse_complement(left_seq)
            
            search_start = i + length + 10
            search_end = min(i + max_distance, seq_len - length)
            
            for j in range(search_start, search_end, 50):
                if sequence[j:j + length] == right_seq_expected:
                    internal_length = j - (i + length)
                    if 20 <= internal_length <= 500:
                        found_repeats.append({
                            'left_pos': i,
                            'right_pos': j,
                            'itr': left_seq,
                            'length': length,
                            'internal': internal_length
                        })
    
    return found_repeats

def analyze_genome(filename, genome_name):
    print("\nanalyzing", genome_name)
    
    try:
        header, sequence = read_fasta(filename)
        print("length:", len(sequence), "bp")
    except FileNotFoundError:
        print("file not found:", filename)
        return []
    
    repeats = find_inverted_repeats(sequence, 4, 6)
    
    print("found", len(repeats), "candidates")
    
    for r in repeats:
        score = r['length'] * 2
        if 50 <= r['internal'] <= 200:
            score += 5
        r['score'] = score
    
    repeats.sort(key=lambda x: x['score'], reverse=True)
    
    top_repeats = repeats[:20]
    
    print("keeping top", len(top_repeats))
    
    return top_repeats

def save_results(results, filename):
    with open(filename, 'w') as f:
        for genome_name, repeats in results.items():
            f.write(f"{genome_name}\n")
            for i, r in enumerate(repeats, 1):
                f.write(f"{i}. pos={r['left_pos']}-{r['right_pos']}, ITR={r['itr']} ({r['length']}bp), internal={r['internal']}bp\n")
            f.write("\n")

def main():
    genomes = [
        ('sequence.fasta', 'Escherichia coli'),
        ('NC_000964.fasta', 'Bacillus subtilis'),
        ('NC_000908.fasta', 'Mycoplasma genitalium')
    ]
    
    all_results = {}
    
    for filename, name in genomes:
        results = analyze_genome(filename, name)
        if results:
            all_results[name] = results
    
    if all_results:
        save_results(all_results, 'transposon_results.txt')
        print("\nsaved to transposon_results.txt")

if __name__ == "__main__":
    main()
