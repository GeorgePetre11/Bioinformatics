def reverse_complement(seq):
    complement = {'A': 'T', 'T': 'A', 'G': 'C', 'C': 'G'}
    return ''.join(complement[base] for base in reversed(seq))

def find_inverted_repeats(sequence, min_length=6, max_length=15, max_gap=100):
    inverted_repeats = []
    seq_len = len(sequence)
    
    for length in range(min_length, max_length + 1):
        for i in range(seq_len - length):
            left_itr = sequence[i:i + length]
            right_itr_expected = reverse_complement(left_itr)
            search_start = i + length
            search_end = min(i + length + max_gap, seq_len - length)
            
            for j in range(search_start, search_end):
                if sequence[j:j + length] == right_itr_expected:
                    inverted_repeats.append({
                        'left_start': i,
                        'left_end': i + length,
                        'right_start': j,
                        'right_end': j + length,
                        'itr_sequence': left_itr,
                        'length': length,
                        'internal_length': j - (i + length)
                    })
    
    return inverted_repeats

def detect_transposons(sequence):
    print("detecting TEs...")
    
    inverted_repeats = find_inverted_repeats(sequence, 6, 15)
    print("found", len(inverted_repeats), "ITR pairs")
    
    candidates = []
    
    for itr in inverted_repeats:
        score = itr['length'] * 2
        if 20 <= itr['internal_length'] <= 50:
            score += 10
        
        left_boundary = itr['left_start']
        right_boundary = itr['right_end']
        
        for tsd_len in range(4, 8):
            if left_boundary >= tsd_len and right_boundary + tsd_len < len(sequence):
                left_tsd = sequence[left_boundary - tsd_len:left_boundary]
                right_tsd = sequence[right_boundary:right_boundary + tsd_len]
                
                if left_tsd == right_tsd:
                    score += 15
                    itr['tsd'] = left_tsd
                    itr['tsd_length'] = tsd_len
                    itr['te_start'] = left_boundary - tsd_len
                    itr['te_end'] = right_boundary + tsd_len
                    break
        
        if 'tsd' not in itr:
            itr['te_start'] = left_boundary
            itr['te_end'] = right_boundary
            itr['tsd'] = 'N/A'
            itr['tsd_length'] = 0
        
        itr['score'] = score
        candidates.append(itr)
    
    candidates.sort(key=lambda x: x['score'], reverse=True)
    candidates = [c for c in candidates if c['score'] >= 15]
    
    final_tes = []
    used_regions = set()
    
    for candidate in candidates:
        start = candidate['te_start']
        end = candidate['te_end']
        overlap = False
        for pos in range(start, end):
            if pos in used_regions:
                overlap = True
                break
        
        if not overlap:
            final_tes.append(candidate)
            for pos in range(start, end):
                used_regions.add(pos)
    
    return final_tes

def main():
    with open('test_sequence.fasta', 'r') as f:
        lines = f.readlines()
        sequence = ''.join([line.strip() for line in lines if not line.startswith('>')])
    
    print("sequence length:", len(sequence))
    
    detected_tes = detect_transposons(sequence)
    
    print("\nfound", len(detected_tes), "TEs:")
    for i, te in enumerate(detected_tes, 1):
        print(f"TE {i}: {te['te_start']}-{te['te_end']}, ITR={te['itr_sequence']}, TSD={te['tsd']}")
    
    with open('detection_results.txt', 'w') as f:
        for i, te in enumerate(detected_tes, 1):
            f.write(f"TE {i}: start={te['te_start']}, end={te['te_end']}, ITR={te['itr_sequence']}, TSD={te['tsd']}\n")

if __name__ == "__main__":
    main()
