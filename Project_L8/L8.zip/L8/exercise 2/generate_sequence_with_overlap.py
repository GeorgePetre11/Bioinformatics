import random

def generate_random_dna(length):
    return ''.join(random.choices(['A', 'T', 'G', 'C'], k=length))

def reverse_complement(seq):
    complement = {'A': 'T', 'T': 'A', 'G': 'C', 'C': 'G'}
    return ''.join(complement[base] for base in reversed(seq))

def create_transposable_element(itr_length=10, internal_length=30):
    itr_left = generate_random_dna(itr_length)
    itr_right = reverse_complement(itr_left)
    internal = generate_random_dna(internal_length)
    return itr_left + internal + itr_right, itr_left, itr_right

def insert_te_with_tsd(sequence, position, te, tsd_length=5):
    if position + tsd_length > len(sequence):
        position = len(sequence) - tsd_length
    tsd = sequence[position:position + tsd_length]
    new_sequence = sequence[:position] + tsd + te + tsd + sequence[position + tsd_length:]
    return new_sequence, position, tsd

def main():
    random.seed(42)
    
    base_length = random.randint(100, 150)
    dna_sequence = generate_random_dna(base_length)
    
    print(f"Initial sequence: {len(dna_sequence)} bp")
    print(f"Inserting 4 transposable elements...\n")
    
    te_info = []
    
    itr_len = random.randint(8, 12)
    internal_len = random.randint(20, 35)
    te, itr_left, itr_right = create_transposable_element(itr_len, internal_len)
    position = random.randint(0, len(dna_sequence) - 5)
    tsd_length = random.randint(4, 6)
    dna_sequence, actual_pos, tsd = insert_te_with_tsd(dna_sequence, position, te, tsd_length)
    
    te_info.append({'number': 1, 'position': actual_pos, 'end': actual_pos + tsd_length + len(te) + tsd_length,
                    'itr_left': itr_left, 'tsd': tsd, 'full_te': te})
    print(f"TE #1: pos {actual_pos}, TSD: {tsd}")
    
    itr_len = random.randint(8, 12)
    internal_len = random.randint(20, 35)
    te, itr_left, itr_right = create_transposable_element(itr_len, internal_len)
    position = random.randint(0, len(dna_sequence) - 5)
    tsd_length = random.randint(4, 6)
    dna_sequence, actual_pos, tsd = insert_te_with_tsd(dna_sequence, position, te, tsd_length)
    te_info.append({'number': 2, 'position': actual_pos, 'end': actual_pos + tsd_length + len(te) + tsd_length,
                    'itr_left': itr_left, 'tsd': tsd, 'full_te': te})
    print(f"TE #2: pos {actual_pos}, TSD: {tsd}")
    
    prev_te = te_info[-1]
    overlap_position = prev_te['position'] + len(te) // 2
    itr_len = random.randint(8, 12)
    internal_len = random.randint(20, 35)
    te, itr_left, itr_right = create_transposable_element(itr_len, internal_len)
    tsd_length = random.randint(4, 6)
    dna_sequence, actual_pos, tsd = insert_te_with_tsd(dna_sequence, overlap_position, te, tsd_length)
    te_info.append({'number': 3, 'position': actual_pos, 'end': actual_pos + tsd_length + len(te) + tsd_length,
                    'itr_left': itr_left, 'tsd': tsd, 'full_te': te, 'overlapping': True})
    print(f"TE #3: pos {actual_pos}, TSD: {tsd} (overlapping)")
    
    prev_te = te_info[-1]
    overlap_position = prev_te['position'] + len(te) // 3
    itr_len = random.randint(8, 12)
    internal_len = random.randint(20, 35)
    te, itr_left, itr_right = create_transposable_element(itr_len, internal_len)
    tsd_length = random.randint(4, 6)
    dna_sequence, actual_pos, tsd = insert_te_with_tsd(dna_sequence, overlap_position, te, tsd_length)
    te_info.append({'number': 4, 'position': actual_pos, 'end': actual_pos + tsd_length + len(te) + tsd_length,
                    'itr_left': itr_left, 'tsd': tsd, 'full_te': te, 'overlapping': True})
    print(f"TE #4: pos {actual_pos}, TSD: {tsd} (overlapping)")
    
    print(f"\nFinal sequence: {len(dna_sequence)} bp")
    
    with open('test_sequence.fasta', 'w') as f:
        f.write(f">Test_sequence\n")
        for i in range(0, len(dna_sequence), 60):
            f.write(dna_sequence[i:i+60] + '\n')
    
    with open('ground_truth.txt', 'w') as f:
        f.write(f"Ground Truth\n")
        f.write(f"Sequence length: {len(dna_sequence)} bp\n")
        f.write(f"Number of TEs: {len(te_info)}\n\n")
        for te in te_info:
            overlap = " (overlapping)" if te.get('overlapping', False) else ""
            f.write(f"TE #{te['number']}{overlap}:\n")
            f.write(f"  Start: {te['position']}\n")
            f.write(f"  End: {te['end']}\n")
            f.write(f"  TSD: {te['tsd']}\n")
            f.write(f"  ITR: {te['itr_left']}\n")
            f.write(f"  Sequence: {te['full_te']}\n\n")
    
    print("Files saved")

if __name__ == "__main__":
    main()
