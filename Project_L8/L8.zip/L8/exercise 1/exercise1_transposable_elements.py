import random

def generate_random_dna(length):
    return ''.join(random.choices(['A', 'T', 'G', 'C'], k=length))

def reverse_complement(seq):
    complement = {'A': 'T', 'T': 'A', 'G': 'C', 'C': 'G'}
    return ''.join(complement[base] for base in reversed(seq))

def create_transposable_element(itr_length=10, internal_length=30):
    itr_left = generate_random_dna(itr_length)
    itr_right = reverse_complement(itr_left)
    internal = generate_random_dna(internal_length)
    te = itr_left + internal + itr_right
    return te, itr_left, itr_right

def insert_te_with_tsd(sequence, position, te, tsd_length=5):
    if position + tsd_length > len(sequence):
        position = len(sequence) - tsd_length
    
    tsd = sequence[position:position + tsd_length]
    new_sequence = sequence[:position] + tsd + te + tsd + sequence[position + tsd_length:]
    
    return new_sequence, position, tsd

def main():
    random.seed(42)
    
    base_length = random.randint(100, 150)
    dna_sequence = generate_random_dna(base_length)
    
    print("initial length:", len(dna_sequence))
    
    num_tes = random.randint(3, 4)
    print("inserting", num_tes, "TEs")
    
    te_info = []
    
    for i in range(num_tes):
        itr_len = random.randint(8, 12)
        internal_len = random.randint(20, 35)
        te, itr_left, itr_right = create_transposable_element(itr_len, internal_len)
        
        position = random.randint(0, len(dna_sequence) - 5)
        tsd_length = random.randint(4, 6)
        
        dna_sequence, actual_pos, tsd = insert_te_with_tsd(dna_sequence, position, te, tsd_length)
        
        te_info.append({
            'number': i + 1,
            'position': actual_pos,
            'length': len(te),
            'itr_left': itr_left,
            'itr_right': itr_right,
            'tsd': tsd,
            'tsd_length': tsd_length,
            'full_te': te
        })
        
        print("TE", i+1, "at position", actual_pos)
    
    print("final length:", len(dna_sequence))
    
    with open('artificial_sequence.fasta', 'w') as f:
        f.write(">sequence\n")
        f.write(dna_sequence + '\n')
    
    with open('te_annotation.txt', 'w') as f:
        for te in te_info:
            f.write(f"TE {te['number']}: pos {te['position']}, ITR_L={te['itr_left']}, ITR_R={te['itr_right']}, TSD={te['tsd']}\n")
    
    print("done")

if __name__ == "__main__":
    main()
