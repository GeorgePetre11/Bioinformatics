Team:
Petre George-Alexandru 1241B
Uritu Andra-Ioana 1241B