from lab4 import GENETIC_CODE
import matplotlib.pyplot as plt
from collections import Counter
from Bio import SeqIO
import requests
import os

def download_genome(accession, filename):
    url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nucleotide&id={accession}&rettype=fasta"
    response = requests.get(url)
    with open(filename, 'w') as f:
        f.write(response.text)

def get_codons(sequence, step=3):
    return [sequence[i:i+3] for i in range(0, len(sequence)-2, 3)]

def analyze_genome(filename):
    record = next(SeqIO.parse(filename, "fasta"))
    sequence = str(record.seq)
    codons = get_codons(sequence)
    codon_freq = Counter(codons)
    return codon_freq

def plot_top_codons(codon_freq, title, output_file):
    top_10 = dict(sorted(codon_freq.items(), key=lambda x: x[1], reverse=True)[:10])
    plt.figure(figsize=(12, 6))
    plt.bar(top_10.keys(), top_10.values())
    plt.title(title)
    plt.xticks(rotation=45)
    plt.ylabel('Frequency')
    plt.tight_layout()
    plt.savefig(output_file)
    plt.close()
    return top_10

def main():
    covid_acc = "NC_045512.2"
    flu_acc = "NC_007373.1"
    
    download_genome(covid_acc, "covid19.fasta")
    download_genome(flu_acc, "influenza.fasta")
    
    covid_codons = analyze_genome("covid19.fasta")
    flu_codons = analyze_genome("influenza.fasta")
    
    covid_top10 = plot_top_codons(covid_codons, "COVID-19 Top 10 Codons", "covid_codons.png")
    flu_top10 = plot_top_codons(flu_codons, "Influenza Top 10 Codons", "flu_codons.png")
    
    print("\nTop 3 codons in COVID-19:")
    for codon, freq in list(covid_top10.items())[:3]:
        print(f"{codon}: {freq} ({GENETIC_CODE.get(codon, 'Unknown')})")
    
    print("\nTop 3 codons in Influenza:")
    for codon, freq in list(flu_top10.items())[:3]:
        print(f"{codon}: {freq} ({GENETIC_CODE.get(codon, 'Unknown')})")
    
    common_codons = set(dict(list(covid_top10.items())[:10]).keys()) & \
                   set(dict(list(flu_top10.items())[:10]).keys())
    
    print("\nCommon codons in top 10:")
    for codon in common_codons:
        print(f"{codon} ({GENETIC_CODE.get(codon, 'Unknown')})")

if __name__ == "__main__":
    main()